<?php
require __DIR__ . "/../acm/SysFileAutoLoader.php";


if (isset($_GET['add_new_lead']) == "true") {
    $ApiAuthenticationKey = $_GET['key'];
    $Key = SECURE($_GET['key'], "d");

    if ($Key == 1) {

        $leads = [
            "LeadPersonFullname" => $_GET['full_name'],
            "LeadPersonPhoneNumber" => $_GET['phone_number'],
            "LeadPersonEmailId" => $_GET['email_id'],
            "LeadPersonAddress" => $_GET['address_locality'],
            "LeadPersonSource" => $_GET['source'],
            "LeadPersonManagedBy" => "", //dynamic distribution of leads
            "LeadPriorityLevel" => $_GET['priority_level'],
            "LeadPersonCreatedAt" => CURRENT_DATE_TIME,
            "LeadPersonNotes" => SECURE($_GET['remarks'], "e"),
            "LeadPersonLastUpdatedAt" => CURRENT_DATE_TIME
        ];

        $check = CHECK("SELECT * FROM leads where LeadPersonPhoneNumber='" . $_GET['phone_number'] . "'");
        if ($check == null) {
            $SAVE = INSERT("leads", $leads);
        } else {
            $SAVE = false;
        }

        if ($SAVE == true) {
            echo "true";
        } else {
            echo "false";
        }
    } else {
        echo "Invalid Authentication Key";
    }
}
